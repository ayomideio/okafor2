const mongoose = require("mongoose");



const Maintenance = mongoose.model(
  "Maintenance",
  new mongoose.Schema({
    tenantId:String,
    comments:String,
    rop: String
  })
);

module.exports = Maintenance;
