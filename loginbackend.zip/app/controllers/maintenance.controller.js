const config = require("../config/auth.config");
const db = require("../models");
const Maintenance = db.maintenance;

var jwt = require("jsonwebtoken");
var bcrypt = require("bcryptjs");

exports.createmaintenance = (req, res) => {
  if (req.body.operate ==='create'){
  const maintenance = new Maintenance({
    tenantId:req.body.tenantId,
    comments:req.body.comments,
    rop: req.body.rop
  });

  maintenance.save((err, user) => {
    if (err) {
      res.status(500).send({ message: err });
      return;
    }

    
  });
}
};


exports.getmaintenance=(req,res)=>{
  Maintenance.find()
  .then(maintenances => {
      res.send(maintenances);
  }).catch(err => {
      res.status(500).send({
          message: err.message || "Some error occured"
      });
  });


}




