module.exports = {
  HOST: "cluster0.n9ojf.mongodb.net",
  PORT: 27017,
  DB: "Al_Jabeer"
};