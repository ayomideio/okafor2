module.exports = {
  secret: "ayomideio-secret-key"
};
